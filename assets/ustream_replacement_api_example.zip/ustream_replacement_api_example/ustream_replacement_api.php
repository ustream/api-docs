<?php
require __DIR__ . '/vendor/autoload.php';

# API host
define("API_HOST", "https://api.video.ibm.com");
# Redirect URL for token generation
define("REDIRECT_URL", "https://video.ibm.com");
#Insert your Ustream credentials here
define("USER_NAME", "<USER_NAME>");
define("PASSWORD", "<PASSWORD>");
define("CLIENT_ID", "<CLIENT_ID>");
define("CLIENT_SECRET", "<CLIENT_SECRET>");
#Name of the video you want to upload for replacement, it has to be the same folder as the current script
define("FILE_NAME", "<FILE_NAME>");
define("FILE_EXTENSION", "<FILE_EXTENSION>");
define("VIDEO_ID", "<VIDEO_ID>");
#Insert Initial parameters for replacement: boolean (required).
define("REGENERATE_THUMBNAIL", "<REGENERATE_THUMBNAIL>");
define("REGENERATE_TRANSCRIPT", "<REGENERATE_TRANSCRIPT>");


echo "Ustream Video Replacement API basic usage:\n";

$client = new \GuzzleHttp\Client();
echo "--------------------------\n";
echo "----- Authentication --------\n";
echo "--------------------------\n";
$auth_token = login($client);

echo "\n\n--------------------------\n";
echo "----- Replace a video  ----\n";
echo "--------------------------\n";
replaceVideo($client, $auth_token, VIDEO_ID);

function login($client) {
    $auth_token = "";
    if (empty(PASSWORD)) {
        echo "Visit the authorization site, log in and copy your access token below: https://authentication.video.ibm.com/authorize?client_id=" . CLIENT_ID . "&response_type=token&redirect_uri=" . REDIRECT_URL . PHP_EOL;
        $auth_token = readline("Your access token: ");
    } else {
        $res = $client->request('POST', 'https://www.ustream.tv/oauth2/token', [
            'headers' => [
                #insert your client_secret here
                'Authorization' => 'Basic ' . CLIENT_SECRET
            ],
            'form_params' => [
                #insert your client_id here
                'client_id' => CLIENT_ID,
                'username' => USER_NAME,
                'password' => PASSWORD,
                'grant_type' => 'password',
                'device_name' => 'UstreamTesting',
                'scope' => 'offline+broadcaster',
                'token_type' => 'bearer'
            ]
        ]);
        if ($res->getStatusCode() == 200) {
            $response = json_decode($res->getBody());
            $auth_token = $response->access_token;
            printPretty($response);
        }
    }
    return $auth_token;
}

function replaceVideo($client, $auth_token, $video_id) {
    $ret = initVideoReplace($client, $auth_token, $video_id);
    uploadFileParts($client, $auth_token, $video_id, $ret['uploadId']);
    videoReplacementUploadCompleted($client, $auth_token, $video_id, $ret['uploadId']);

    # Check video upload status
    while (true) {
        $status = getVideoUploadStatus($client, $auth_token, $video_id, $ret['channelId']);
        if ($status == 'error') {
            throw new \Exception("Video transcoding failed");
        }
        if ($status == 'complete') {
            break;
        }

        sleep(5);
    }
}

function initVideoReplace($client, $auth_token, $video_id) {
    echo "\n\n";
    echo "------------------------------\n";
    echo "-----Video replacement init ------\n";
    echo "------------------------------\n";

    $res = $client->request('POST', API_HOST.'/videos/'.$video_id.'/replacement.json', [
        'headers' => [
            'Authorization' => 'Bearer ' . $auth_token
        ],
        'form_params' => [
            'regenerateThumbnail' => REGENERATE_THUMBNAIL,
            'regenerateTranscript' => REGENERATE_TRANSCRIPT
        ]
    ]);
    if ($res->getStatusCode() == 201) {
        $response = json_decode($res->getBody());
        printPretty($response);
        return json_decode($res->getBody(), true);
    } else {
        $response = json_decode($res->getBody());
        printPretty($response);
        throw new \Exception("Failed to init video replacement");
    }
}

function uploadFileParts($client, $auth_token, $video_id, $upload_id) {
    echo "\n\n";
    echo "-------------------------------\n";
    echo "----- Upload video parts ------\n";
    echo "-------------------------------\n";

    $filename = sprintf('%s.%s', FILE_NAME, FILE_EXTENSION);
    $fp = fopen($filename, 'rb');
    if ($fp === false) {
        return false;
    }

    $size = filesize($filename);
    $blocksize = 1 * 1024 * 1024;
    $total_part_count = ceil($size / $blocksize);

    $progress = 0;
    $failures = 0;
    $part_idx = 1;
    while ($progress < $size) {
        if ($size - $progress < $blocksize) {
            $slice = $size - $progress;
        } else {
            $slice = $blocksize;
        }

        $data = fread($fp, $slice);

        $res = $client->request('POST', API_HOST.'/videos/'.$video_id.'/replacement/part.json', [
            'headers' => [
                'Authorization' => 'Bearer ' . $auth_token
            ],
            'multipart' => [
                [
                    'name'     => 'uploadId',
                    'contents' => $upload_id
                ],
                [
                    'name'     => 'partIndex',
                    'contents' => $part_idx
                ],
                [
                    'name'     => 'totalPartCount',
                    'contents' => $total_part_count
                ],
                [
                    'name'     => 'totalFileSize',
                    'contents' => $size
                ],
                [
                    'name'     => 'file',
                    'contents' => $data,
                    'filename' => $filename
                ]
            ]
        ]);

        echo sprintf('Size: %d, Progress: %d, Blocksize: %d, Slice: %d, PartIdx: %d, StatusCode: %d', $size, $progress, $blocksize, $slice, $part_idx, $res->getStatusCode()) . PHP_EOL;
        if ($res->getStatusCode() == 200) {
            $progress += $slice;
            $part_idx += 1;
        } else {
            $response = json_decode($res->getBody());
            printPretty($response);
            fclose($fp);
            throw new \Exception("Failed to upload video part");
        }
    }

    fclose($fp);
    return;
}

function videoReplacementUploadCompleted($client, $auth_token, $video_id, $upload_id) {
    echo "\n\n";
    echo "-----------------------------------\n";
    echo "----- Replacement upload completed ------\n";
    echo "-----------------------------------\n";

    $res = $client->request('POST', API_HOST.'/videos/'.$video_id.'/replacement/completed.json', [
        'headers' => [
            'Authorization' => 'Bearer ' . $auth_token
        ],
        'form_params' => [
            'uploadId' => $upload_id
        ]
    ]);
    if ($res->getStatusCode() == 200) {
        $response = json_decode($res->getBody());
        printPretty($response);
        return json_decode($res->getBody(), true);
    } else {
        $response = json_decode($res->getBody());
        printPretty($response);
        throw new \Exception("Failed to complete video replacement");
    }
}

function getVideoUploadStatus($client, $auth_token, $video_id, $channel_id) {
    echo "\n\n";
    echo "-----------------------------------\n";
    echo "------- Video replacement status -------\n";
    echo "-----------------------------------\n";

    $res = $client->request('GET', API_HOST.'/channels/'.$channel_id.'/uploads/'.$video_id.'.json', [
        'headers' => [
            'Authorization' => 'Bearer ' . $auth_token
        ]
    ]);
    if ($res->getStatusCode() == 200) {
        $response = json_decode($res->getBody());
        printPretty($response);
        return json_decode($res->getBody(), true)['status'];
    } else {
        $response = json_decode($res->getBody());
        printPretty($response);
        throw new \Exception("Failed to complete video upload");
    }
}

function printPretty($response) {
    echo json_encode($response, JSON_PRETTY_PRINT)."\n";
}
