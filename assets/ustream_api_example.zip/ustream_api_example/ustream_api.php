<?php
require __DIR__ . '/vendor/autoload.php';

# API host
define("API_HOST", "https://api.ustream.tv");
#insert your Ustream credentials here
define("USER_NAME", "<USER_NAME>");
define("PASSWORD", "<PASSWORD>");
define("CLIENT_ID", "<CLIENT_ID>");
define("CLIENT_SECRET", "<CLIENT_SECRET>");
#name of the video you want to upload, it has to be the same folder as the current script
define("FILE_NAME", "<FILE_NAME>");
define("FILE_EXTENSION", "<FILE_EXTENSION>");
define("CHANNEL_ID", "<CHANNEL_ID>");

echo "Ustream API basic usage:\n";

$client = new \GuzzleHttp\Client();
echo "--------------------------\n";
echo "----- Authentication --------\n";
echo "--------------------------\n";
$auth_token = login($client);

echo "\n\n--------------------------\n";
echo "----- List channels ------\n";
echo "--------------------------\n";
$channel_ids = getChannels($client, $auth_token);

echo "\n\n--------------------------\n";
echo "----- List videos   ------\n";
echo "--------------------------\n";
$videos = getVideoes($client, $auth_token, $channel_ids[0]);

echo "\n\n--------------------------\n";
echo "----- Upload a video  ----\n";
echo "--------------------------\n";
uploadVideoNew($client, $auth_token, $channel_ids[0]);

/**
 * This version of the video upload is deprecated and soon will be discontinued. Please use {@link uploadVideoNew()}
 */
/*
echo "\n\n--------------------------\n";
echo "----- Upload a video (depricated)  ----\n";
echo "--------------------------\n";
uploadVideo($client, $auth_token, $channel_ids[0]);
*/

if (count($videos) > 0) {
    echo "\n\n--------------------------\n";
    echo "----- Download a video ---\n";
    echo "--------------------------\n";
    downloadVideo($client, $auth_token, $videos[0]['id']);
    
    echo "\n\n--------------------------\n";
    echo "----- Request a downloadable video ----\n";
    echo "--------------------------\n";
    requestDownloadVersionOfVideo($client, $auth_token, $videos[0]['id']);
}



function login($client) {
    $res = $client->request('POST', 'https://www.ustream.tv/oauth2/token', [
        'headers' => [
            #insert your client_secret here
            'Authorization' => 'Basic ' . CLIENT_SECRET
        ],
        'form_params' => [
            #insert your client_id here
            'client_id' => CLIENT_ID,
            'username' => USER_NAME,
            'password' => PASSWORD,
            'grant_type' => 'password',
            'device_name' => 'UstreamTesting',
            'scope' => 'offline+broadcaster',
            'token_type' => 'bearer'
            ]
    ]);
    if ($res->getStatusCode() == 200) {
        $response = json_decode($res->getBody());
        $auth_token = $response->access_token;
        printPretty($response);
    }
    return $auth_token;
}

function getChannels($client, $auth_token) {
    $res = $client->request('GET', API_HOST . '/users/self/channels.json', [
        'headers' => [
            'Authorization' => 'Bearer ' . $auth_token
        ]
    ]);
    if ($res->getStatusCode() == 200) {
        $response = json_decode($res->getBody());
        $channel_ids = [];
        foreach($response->channels as $key => $value) {
            array_push($channel_ids, $response->channels->{$key}->id);
        }
        printPretty($response);
    }
    return $channel_ids;
}

function getVideoes($client, $auth_token, $channel_id) {
    $res = $client->request('GET', API_HOST . '/channels/'.$channel_id.'/videos.json', [
        'headers' => [
            'Authorization' => 'Bearer ' . $auth_token
        ],
        'query' => [
            'filter' => [
                'protect' => 'private'
             ]
        ]
    ]);
    if ($res->getStatusCode() == 200) {
        $response = json_decode($res->getBody(), true);
        printPretty($response);
        return $response['videos'];
    }
}

function uploadVideoNew($client, $auth_token, $channel_id) {
    $ret = initVideoUpload($client, $auth_token, $channel_id);
    uploadFileParts($client, $auth_token, $channel_id, $ret['videoId'], $ret['uploadId']);
    videoUploadCompleted($client, $auth_token, $channel_id, $ret['videoId'], $ret['uploadId']);

    # Check video upload status
    while (true) {
        $status = getVideoUploadStatus($client, $auth_token, $channel_id, $ret['videoId']);
        if ($status == 'error') {
            throw new \Exception("Video transcoding failed");
        }
        if ($status == 'complete') {
            break;
        }

        sleep(5);
    }
}

function initVideoUpload($client, $auth_token, $channel_id) {
    echo "\n\n";
    echo "------------------------------\n";
    echo "----- Upload video init ------\n";
    echo "------------------------------\n";

    $res = $client->request('POST', API_HOST.'/v2/channels/'.$channel_id.'/uploads.json', [
        'headers' => [
            'Authorization' => 'Bearer ' . $auth_token
        ],
 	    'form_params' => [
            'title' => "Test video new API title",
            'description' => "Test video new API desciption"
	    ]
    ]);
    if ($res->getStatusCode() == 201) {
        $response = json_decode($res->getBody());
        printPretty($response);
        return json_decode($res->getBody(), true);
    } else {
        $response = json_decode($res->getBody());
        printPretty($response);
        throw new \Exception("Failed to init video upload");
    }
}

function uploadFileParts($client, $auth_token, $channel_id, $video_id, $upload_id) {
    echo "\n\n";
    echo "-------------------------------\n";
    echo "----- Upload video parts ------\n";
    echo "-------------------------------\n";

    $filename = sprintf('%s.%s', FILE_NAME, FILE_EXTENSION);
    $fp = fopen($filename, 'rb');
    if ($fp === false) {
        return false;
    }

    $size = filesize($filename);
    $blocksize = 1 * 1024 * 1024;
    $total_part_count = ceil($size / $blocksize);

    $progress = 0;
    $failures = 0;
    $part_idx = 1;
    while ($progress < $size) {
        if ($size - $progress < $blocksize) {
            $slice = $size - $progress;
        } else {
            $slice = $blocksize;
        }

        $data = fread($fp, $slice);

        $res = $client->request('POST', API_HOST.'/v2/channels/'.$channel_id.'/uploads/'.$video_id.'/part.json', [
            'headers' => [
                'Authorization' => 'Bearer ' . $auth_token
            ],
             'multipart' => [
                [
                    'name'     => 'uploadId',
                    'contents' => $upload_id
                ],
                [
                    'name'     => 'partIndex',
                    'contents' => $part_idx
                ],
                [
                    'name'     => 'totalPartCount',
                    'contents' => $total_part_count
                ],
                [
                    'name'     => 'totalFileSize',
                    'contents' => $size
                ],
                [
                    'name'     => 'file',
                    'contents' => $data,
                    'filename' => $filename
                ]
            ]
        ]);

        echo sprintf('Size: %d, Progress: %d, Blocksize: %d, Slice: %d, PartIdx: %d, StatusCode: %d', $size, $progress, $blocksize, $slice, $part_idx, $res->getStatusCode()) . PHP_EOL;
        if ($res->getStatusCode() == 200) {
            $progress += $slice;
            $part_idx += 1;
        } else {
            $response = json_decode($res->getBody());
            printPretty($response);
            fclose($fp);
            throw new \Exception("Failed to upload video part");
        }
    }

    fclose($fp);
    return;
}

function videoUploadCompleted($client, $auth_token, $channel_id, $video_id, $upload_id) {
    echo "\n\n";
    echo "-----------------------------------\n";
    echo "----- Upload video completed ------\n";
    echo "-----------------------------------\n";

    $res = $client->request('POST', API_HOST.'/v2/channels/'.$channel_id.'/uploads/'.$video_id.'/completed.json', [
        'headers' => [
            'Authorization' => 'Bearer ' . $auth_token
        ],
 	    'form_params' => [
            'uploadId' => $upload_id
	    ]
    ]);
    if ($res->getStatusCode() == 200) {
        $response = json_decode($res->getBody());
        printPretty($response);
        return json_decode($res->getBody(), true);
    } else {
        $response = json_decode($res->getBody());
        printPretty($response);
        throw new \Exception("Failed to complete video upload");
    }
}

function getVideoUploadStatus($client, $auth_token, $channel_id, $video_id) {
    echo "\n\n";
    echo "-----------------------------------\n";
    echo "------- Upload video status -------\n";
    echo "-----------------------------------\n";

    $res = $client->request('GET', API_HOST.'/channels/'.$channel_id.'/uploads/'.$video_id.'.json', [
        'headers' => [
            'Authorization' => 'Bearer ' . $auth_token
        ]
    ]);
    if ($res->getStatusCode() == 200) {
        $response = json_decode($res->getBody());
        printPretty($response);
        return json_decode($res->getBody(), true)['status'];
    } else {
        $response = json_decode($res->getBody());
        printPretty($response);
        throw new \Exception("Failed to complete video upload");
    }
}

/**
 * This version of the video upload is deprecated and soon will be discontinued. Please use {@link uploadVideoNew()}
 */
function uploadVideo($client, $auth_token, $channel_id) {
    # 1. call upload video endpoint to get the details and credentials for ftp connection
    $res = $client->request('POST', API_HOST . '/channels/'.$channel_id.'/uploads.json', [
        'headers' => [
            'Authorization' => 'Bearer ' . $auth_token
        ],
        'query' => [
            'type' => 'videoupload-ftp'
        ],
 	'form_params' => [
            'title' => FILE_NAME,
	    'description' => FILE_NAME
        ]
    ]);
    if ($res->getStatusCode() == 201) {
        $response = json_decode($res->getBody());
        printPretty($response);
        $video_id = $response->videoId;
        $ftp_server = $response->protocol.'.'.$response->host;
        $ftp_user_name = $response->user;
        $ftp_user_pass = $response->password;
	$path = $response->path;
	$url = $response->url;
    }

    # 2. use ftp to upload the video file to the server
    $file = FILE_NAME.".".FILE_EXTENSION;
    $remote_file = substr($path,1).".".FILE_EXTENSION;

    $conn_id = ftp_connect($ftp_server);
    $login_result = ftp_login($conn_id, $ftp_user_name, $ftp_user_pass);
    ftp_pasv($conn_id, true);
    if (ftp_put($conn_id, $remote_file, $file, FTP_BINARY)) {
	echo "Successfully uploaded $file\n";
    } else {
        echo "There was a problem while uploading $file\n";
    }
    ftp_close($conn_id);

    # 3. call file in place endpoint 
    $res = $client->request('PUT', API_HOST . '/channels/'.$channel_id.'/uploads/'.$video_id.'.json', [
        'headers' => [
            'Authorization' => 'Bearer ' . $auth_token
        ],
        'form_params' => [
            'status' => 'ready'
        ]
    ]);
    echo "File in place - Response code: " . $res->getStatusCode()."\n";  
    $response = json_decode($res->getBody());
    printPretty($response);
}

function downloadVideo($client, $auth_token, $video_id) {
    $res = $client->request('GET', API_HOST.'/videos/'.$video_id.'/downloadable/mp4.json', [
        'headers' => [
            'Authorization' => 'Bearer ' . $auth_token
        ]
    ]);
    $response = json_decode($res->getBody());
    printPretty($response);
}

function requestDownloadVersionOfVideo($client, $auth_token, $video_id) {
    $res = $client->request('POST', API_HOST.'/videos/'.$video_id.'/downloadable/mp4.json', [
        'headers' => [
            'Authorization' => 'Bearer ' . $auth_token
        ]
    ]);
    $response = json_decode($res->getBody());
    printPretty($response);
}

function printPretty($response) {
    echo json_encode($response, JSON_PRETTY_PRINT)."\n";
}
